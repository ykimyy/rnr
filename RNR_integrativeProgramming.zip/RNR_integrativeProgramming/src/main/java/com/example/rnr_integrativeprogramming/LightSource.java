package com.example.rnr_integrativeprogramming;

public class LightSource{
    //attributes
    double angleIn;
    double angleOut;
    double distance;

    //setter and getter methods to set and get the angle in & out and the distance
    public void setDistance(double d){
      distance=d;
    }
    public void setAngleIn(double i){
        angleIn=i;
    }
    public void setAngleOut(double o){
        angleOut=o;
    }
    public double getDistance(){
        return  distance;
    }
    public double getAngleIn(){
        return angleIn;
    }
    public double getAngleOut(){
        return angleOut;
    }
}
