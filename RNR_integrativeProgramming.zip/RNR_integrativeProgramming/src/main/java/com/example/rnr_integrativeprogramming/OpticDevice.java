package com.example.rnr_integrativeprogramming;

public abstract class OpticDevice {

    //Attributes
    double indexOfRefraction = 0;
    double angleIn = 0;
    double angleOut = 0;
    double distanceFromLight = 0;

    //constructor to initialize
    public OpticDevice(double indexOfRefraction, double angleIn, double angleOut, double distanceFromLight) {
    this.indexOfRefraction=1;
    this.angleIn=0;
    this.angleOut=0;
    this.distanceFromLight=0;
    }

    //getters for attributes
    public double getIndexOfRefraction(){
        return this.indexOfRefraction;
    }

    public double getAngleIn(){
        return this.angleIn;
    }

    public double getAngleOut(){
        return this.angleOut;
    }

    public double getDistanceFromLight(){
        return this.distanceFromLight;
    }

    //setters for attributes
    public void setIndexOfRefraction(double iof){
        this.indexOfRefraction = iof;
    }

    public void setAngleIn(double anglein){
        this.angleIn = anglein;
    }

    public void setAngleOut(double angleout){
        this.angleOut = angleout;
    }

    public void setDistanceFromLight(double dfl){
        this.distanceFromLight = dfl;
    }

}
