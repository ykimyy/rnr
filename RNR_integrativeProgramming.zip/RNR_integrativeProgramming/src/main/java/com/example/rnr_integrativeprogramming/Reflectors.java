package com.example.rnr_integrativeprogramming;

public abstract class Reflectors extends OpticDevice {
    // attributes for reflector
    double focalLength=0;
    double lensMagn=0;
    double focalPoint=0;
    double imageDistance=0;
    double objectDistance=0;

    //constructor to initialize and call super class
    public Reflectors(double focalLength, double lensMagn, double focalPoint,
                      double indexOfRefraction, double angleIn, double angleOut, double distanceFromLight,
    double imageDistance, double objectDistance) {
        super(indexOfRefraction, angleIn, angleOut, distanceFromLight);
        this.focalLength = focalLength;
        this.lensMagn = lensMagn;
        this.focalPoint = focalPoint;
        this.imageDistance = imageDistance;
        this.objectDistance = objectDistance;

    }


    /*
    getter and setter methods to set and get the focal length, lens magnitude
     */
    public void setFocalLength(double focalLength) {
        this.focalLength = focalLength;
    }

    public double getFocalLength() {
        return focalLength;
    }

    public void setLensMagn(double lensMagn) {
        this.lensMagn = lensMagn;
    }

    public double getLensMagn() {
        return lensMagn;
    }

    public void setFocalPoint(double focalPoint) {
        this.focalPoint = focalPoint;
    }

    public double getFocalPoint() {
        return focalPoint;
    }

    public void setImageDistance(double imageDistance) {
        this.imageDistance = imageDistance;
    }

    public double getImageDistance() {
        return imageDistance;
    }

    public void setObjectDistance(double objectDistance) {
        this.objectDistance = objectDistance;
    }

    public double getObjectDistance() {
        return objectDistance;
    }
}

