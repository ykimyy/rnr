package com.example.rnr_integrativeprogramming;

public abstract class Refractors extends OpticDevice{
    //attributes
    double criticalAngle=0;


    //constructor to initialize and call super class
    public Refractors(double criticalAngle,double indexOfRefraction,double angleIn,double angleOut,double distanceFromLight ){
    super(indexOfRefraction,angleIn,angleOut,distanceFromLight);
    this.criticalAngle=criticalAngle;
   }

    //setter and getter methods to set and get the critical angle
    public void setCriticalAngle(double criticalAngle) {
        this.criticalAngle = criticalAngle;
    }

    public double getCriticalAngle() {
        return criticalAngle;
    }
}
