package com.example.rnr_integrativeprogramming;

public class Mediums extends Refractors{
    //default attributes are related to air
    String material = "air";
    double refractionIndex = 1;
    double vLightInMed = 299702000;
  //constructor to initialize and call super class
  public Mediums(double criticalAngle, String material, double refractionIndex, double vLightInMed,
                 double indexOfRefraction,double angleIn,double angleOut,double distanceFromLight){
        super(criticalAngle,indexOfRefraction,angleIn,angleOut,distanceFromLight);
        this.material = material;
        this.refractionIndex = refractionIndex;
        this.vLightInMed = vLightInMed;

    }

    //getter emthods
    public String getMaterial() {
        return this.material;
    }

    public double getRefractionIndex() {
        return this.refractionIndex;
    }

    public double getvLightInMed() {
        return this.vLightInMed;
    }

    //setter methods
    //material sets the values for other attributes
    public void setMaterial(String material) {
        if (material.equals("air")) {
            this.material = material;
            this.refractionIndex = 1;
            this.vLightInMed = 299702000;
        }
        else if (material.equals("water")) {
            this.material = material;
            this.refractionIndex = 1.333;
            this.vLightInMed = 225000000;
        }
        else if (material.equals("glass")) {
            this.material = material;
            this.refractionIndex = 1.517;
            this.vLightInMed = 200000000;
        }
        else {
            this.material = "vacuum";
            this.refractionIndex = 1;
            this.vLightInMed = 300000000;
        }
    }

    public void setRefractionIndex(double refractionIndex) {
        this.refractionIndex = refractionIndex;
    }

    public void setvLightInMed(double vLightInMed){
        this.vLightInMed = vLightInMed;
    }
}

