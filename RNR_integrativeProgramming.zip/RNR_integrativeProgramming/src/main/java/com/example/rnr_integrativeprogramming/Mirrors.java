package com.example.rnr_integrativeprogramming;

import javafx.scene.paint.Material;

public class Mirrors extends Reflectors {
    //attributes
    double reflectedRay;
    String curvature;

    //constructor to initialize the lens object and call super class
    public Mirrors(double focalLength, double lensMagn, double focalPoint,
                   double indexOfRefraction, double angleIn, double angleOut,
                   double distanceFromLight, double reflectedRay, String curvature, double imageDistance, double objectDistance) {
        super(focalLength, lensMagn, focalPoint,
                indexOfRefraction, angleIn, angleOut, distanceFromLight, imageDistance, objectDistance);
        this.reflectedRay = reflectedRay;
        this.curvature = curvature;
    }
    //setter and getter methods
    public void setReflectedRay(double rF) {
        reflectedRay = rF;
    }

    public double getReflectedRay() {
        return reflectedRay;
    }

    public void setCurvature(String c) {
        curvature = c;
    }

    public String getCurvature() {
        return curvature;
    }



}

