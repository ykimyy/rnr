package com.example.rnr_integrativeprogramming;

public class Lens extends Reflectors{
    //attributes of the lens
    double lensPower;
    String curvature;

    //constructor to initialize the lens object and call super class
    public Lens(double focalLength, double lensMagn, double focalPoint, double indexOfRefraction, double angleIn,
                double angleOut, double distanceFromLight,double lensPower,String curvature, double imageDistance, double objectDistance){
        super(focalLength,lensMagn,focalPoint,indexOfRefraction,angleIn,angleOut,distanceFromLight,
                imageDistance,objectDistance);
        this.lensPower=lensPower;
        this.curvature=curvature;
    }
    //getter and setter methods to set and get lens power, and lens curvature
    public void setLensPower(double lP){
        lensPower=lP;
    }
    public double getLensPower(){
        return lensPower;
    }
    public void setCurvature(String c){
    curvature=c;
    }
    public String getCurvature(){
        return curvature;
    }
    
}
