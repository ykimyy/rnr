module com.example.rnr_integrativeprogramming {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.rnr_integrativeprogramming to javafx.fxml;
    exports com.example.rnr_integrativeprogramming;
}